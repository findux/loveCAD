package.path = "src/?.lua;"..package.path
local mgl = require("MGL")
