-- https://github.com/ImagicTheCat/MGL
-- MIT license (see LICENSE or MGL.lua)

-- load
return function(mgl)
end
